package com.CodeFury1.Service;



import java.util.List;

import com.CodeFury1.Entity.Account;
import com.CodeFury1.Entity.Customer;
import com.CodeFury1.Entity.Employee;

public interface EmployeeServiceInterface {
	
	public Employee loginEmployeeService(Employee e);
	
	public int insertCustomerandAccount(Customer c,Account a);

	public int insertAccount(Account a);
	public List<Integer> fetchcustid();
	
}
