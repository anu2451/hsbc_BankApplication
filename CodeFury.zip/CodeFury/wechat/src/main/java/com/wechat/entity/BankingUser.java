package com.wechat.entity;

import java.sql.Timestamp;

public class BankingUser {

private int cust_id;
private String cust_name;
private String username;
private String password;
private String acc_no;
private String acc_type;
private int min_bal;
private Timestamp last_login;

private String input1;
private String input2;
private String DOB;
private String PAN;
private String EMAIL;
private String phone;


public Timestamp getLast_login() {
	return last_login;
}
public void setLast_login(Timestamp last_login) {
	this.last_login = last_login;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public int getCust_id() {
	return cust_id;
}
public void setCust_id(int cust_id) {
	this.cust_id = cust_id;
}
public int getMin_bal() {
	return min_bal;
}
public void setMin_bal(int min_bal) {
	this.min_bal = min_bal;
}

public String getCust_name() {
	return cust_name;
}
public void setCust_name(String cust_name) {
	this.cust_name = cust_name;
}
public String getInput1() {
	return input1;
}
public void setInput1(String input1) {
	this.input1 = input1;
}
public String getInput2() {
	return input2;
}
public void setInput2(String input2) {
	this.input2 = input2;
}
public String getDOB() {
	return DOB;
}
public void setDOB(String dOB) {
	DOB = dOB;
}
public String getPAN() {
	return PAN;
}
public void setPAN(String pAN) {
	PAN = pAN;
}
public String getEMAIL() {
	return EMAIL;
}
public void setEMAIL(String eMAIL) {
	EMAIL = eMAIL;
}



public String getAcc_no() {
	return acc_no;
}
public void setAcc_no(String acc_no) {
	this.acc_no = acc_no;
}
public String getAcc_type() {
	return acc_type;
}
public void setAcc_type(String acc_type) {
	this.acc_type = acc_type;
}

public String getName() {
	return cust_name;
}
public void setName(String cust_name) {
	this.cust_name = cust_name;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;

}
}
